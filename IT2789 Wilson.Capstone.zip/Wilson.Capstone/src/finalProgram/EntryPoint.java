package finalProgram;

public class EntryPoint {

	public static void main(String[] args) 
	{
	new CapstoneFinal();
		// TODO Auto-generated method stub

	}

}
