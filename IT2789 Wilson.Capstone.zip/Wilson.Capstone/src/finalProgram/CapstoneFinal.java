package finalProgram;

import javax.swing.JOptionPane;

public class CapstoneFinal 
{
	public CapstoneFinal() 
	{		
	String input;
	
	String theNumber = "";
	
	String theResult = "";
	
	input = JOptionPane.showInputDialog("input a number");
	JOptionPane.showMessageDialog(null, input);
	
	theResult = decodeOnes(theNumber);
	
	input += "the number in words is " + theResult;
	
	JOptionPane.showMessageDialog(null, theResult);
	}
	
	public String oneCharToWord(String theNumber)
	{
		String theResult = "";
		if (theNumber.length() == 1)
		{
			theResult += decodeOnes(theNumber);
		}
		return theResult;
	}
	
	public String twoCharToWord(String theNumber)
	{
		String theResult = "";
		if (theNumber.length() == 2 && theNumber.charAt(0) != 1)
		{
			theResult += decodeTens(theNumber);
		}
		return theResult;
	}
	
	public String threeCharToWord(String theNumber)
	{
		String theResult = "";
		if (theNumber.length() == 3)
		{
			theResult += decodeHundreds(theNumber);
		}
		return theResult;
	}
	
	public String decodeOnes(String theNumber)
	{
		if (theNumber.length() == 1)
		{
			char theChar = findChar(theNumber, 1);
			return decodeOnesAndHundreds(theChar);
		}
		return "";
	}
	
	public String decodeTens(String theNumber)
	{
		if (theNumber.length() == 2)
		{
			char theChar = findChar(theNumber, 2);
			return decodeTens(theChar);
		}
		return "";
	}
	
	public String decodeHundreds(String theNumber)
	{
		if (theNumber.length() == 3)
		{
			char theChar = findChar(theNumber, 3);
			return decodeOnesAndHundreds(theChar) + "hundred";
		}
		return "";
	}
	

	public String decodeOnesAndHundreds(char theChar)
	{
	String theWord;
	
	switch (theChar)
	{
	case 0:
		theWord = "";
		break;
	case 1:
		theWord = "one";
		break;
	case 2:
		theWord = "two";
		break;
	case 3:
		theWord = "three";
		break;
	case 4:
		theWord = "four";
		break;
	case 5:
		theWord = "five";
		break;
	case 6:
		theWord = "six";
		break;
	case 7:
		theWord = "seven";
		break;
	case 8:
		theWord = "eight";
		break;
	case 9:
		theWord = "nine";
		break;
	default:
		theWord="";
		break;
	}
	return theWord;
	}
	
	public String decodeTeens(char theChar)
	{
		String theWord;
		
		switch (theChar)
		{
		case 0:
			theWord = "";
			break;
		case 1:
			theWord = "eleven";
			break;
		case 2:
			theWord = "twelve";
			break;
		case 3:
			theWord = "thirteen";
			break;
		case 4:
			theWord = "fourteen";
			break;
		case 5:
			theWord = "fifteen";
			break;
		case 6:
			theWord = "sixteen";
			break;
		case 7:
			theWord = "seventeen";
			break;
		case 8:
			theWord = "eighteen";
			break;
		case 9:
			theWord = "nineteen";
			break;
		default:
				theWord="";
				break;
		}
		return theWord;
	}
	
	public String decodeTens(char theChar)
	{
		String theWord;
		
		switch (theChar)
		{
		case 0:
			theWord = "";
			break;
		case 1:
			theWord = "ten";
			break;
		case 2:
			theWord = "twenty";
			break;
		case 3:
			theWord = "thirty";
			break;
		case 4:
			theWord = "fourty";
			break;
		case 5:
			theWord = "fifty";
			break;
		case 6:
			theWord = "sixty";
			break;
		case 7:
			theWord = "seventy";
			break;
		case 8:
			theWord = "eighty";
			break;
		case 9:
			theWord = "ninety";
			break;
		default:
				theWord="";
				break;
		}
		return theWord;
	}
	
	public char findChar(String theNumber, int theDigit)
	{
		char theChar;
		
		int numChars = theNumber.length();
		
		numChars -= theDigit;
		
		theChar = theNumber.charAt(numChars);
		
		return theChar;
	}
}